PADARIA DO CHICO — CARRINHO + CHECKOUT (v1)

Arquivos:
- cart.css       → estilos do carrinho flutuante e painel lateral (moderno)
- cart.js        → lógica do carrinho com LocalStorage + painel
- checkout.html  → página de checkout com máscaras, ViaCEP e validação (Viamão-RS)
- index_injection.html → snippet para inserir no <head> do index.html (ou template)

Como instalar:
1) Copie cart.css, cart.js e checkout.html para a mesma pasta do seu index.html.
2) No seu index.html, dentro de <head>, cole o conteúdo de index_injection.html (ou apenas os 2 links).
3) Em cada card de produto, adicione um botão com as data-attributes:
   <button class="add-to-cart" data-id="ID-UNICO" data-name="NOME" data-price="PRECO">Adicionar</button>

Observações:
- O botão flutuante do carrinho aparece no canto inferior ESQUERDO (preto, ícone branco).
- O painel do carrinho abre da DIREITA para a ESQUERDA.
- O checkout permite entrega APENAS em Viamão - RS (validação via ViaCEP).

Futuro (BeehivePay):
- No checkout, dentro do btnConfirm.addEventListener, substitua o trecho de "Simular registro local"
  por uma chamada fetch() para a API da BeehivePay.
- Exemplo (futuro):
  fetch('https://api.beehivepay.com/...', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer SEU_TOKEN' },
    body: JSON.stringify(pedido)
  }).then(r => r.json()).then(data => {
    // data deve conter o QR Code PIX / payload / status
    // Exiba o QR code para o usuário ou redirecione para página de pagamento
  });

Qualquer dúvida, me chama que eu plugo a API pra você.
